<?php
session_start();  // Start a session to manage user login

// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "portfolio");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Check if the username and password fields are not empty
    if (empty($username) || empty($password)) {
        echo "Please fill in both username and password.";
        exit;
    }

    // Prepare the SQL query to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // If login is successful, redirect to index.html
        header("Location: index.html");
        exit;
    } else {

        header("Location: index2.html");
        exit;
    }

    $stmt->close();
}
$conn->close();
?>
