<?php
$servername = "localhost";   // MySQL server (use localhost if running locally)
$username = "root";          // MySQL username
$password = "";              // MySQL password (leave blank for local XAMPP setup)
$dbname = "portfolio";       // Database name

// Create connection to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$risk_tolerance = $_POST['risk_tolerance'];
$investment_goals = $_POST['investment_goals'];
$personal_preferences = $_POST['personal_preferences'];
$capital = floatval($_POST['capital']);  // Convert to float

// SQL query to insert form data into the 'input' table
$sql = "INSERT INTO input (risk_tolerance, investment_goals, personal_preferences, capital) 
        VALUES ('$risk_tolerance', '$investment_goals', '$personal_preferences', '$capital')";

// Execute query
if ($conn->query($sql) === TRUE) {
    // **Run Python script after successful insertion**
    $command = "python3 kank.py < input.txt";
    exec($command, $output, $return_var);
    
    if ($return_var === 0) {
        echo "Python script executed successfully.";
    } else {
        echo "Error executing Python script.";
    }
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
