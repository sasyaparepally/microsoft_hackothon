<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "portfolio";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT risk_tolerance, investment_goals, personal_preferences, capital FROM input ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $risk_tolerance = $row['risk_tolerance'];
    $investment_goals = $row['investment_goals'];
    $personal_preferences = $row['personal_preferences'];
    $capital = $row['capital'];

    // Write data to input.txt
    $file = fopen("input.txt", "w");
    fwrite($file, "$risk_tolerance\n$investment_goals\n$personal_preferences\n$capital\n");
    fclose($file);

    $command = escapeshellcmd("python " . __DIR__ . "\\a.py " . __DIR__ . "\\input.txt 2>&1");
    $output = shell_exec($command);  // Capture Python output and errors
    echo "<pre>$output</pre>";  // Display any Python output or error
    

    if (!empty($output)) {  // Proceed if the Python script produces output
        echo "<pre>$output</pre>";

        // Check if output.html exists, display its content, and open it in VS Code
        if (file_exists('output.html')) {
            echo file_get_contents('output.html');  // Show the content of output.html

            // Command to open the file in VS Code automatically
            shell_exec("code output.html");  
        } else {
            echo "Error: Output HTML file not found.<br>";
        }
    } else {
        echo "Error: Python script did not execute properly or returned no output.<br>";
    }
} else {
    echo "No data found in the input table.<br>";
}

$conn->close();
?>
